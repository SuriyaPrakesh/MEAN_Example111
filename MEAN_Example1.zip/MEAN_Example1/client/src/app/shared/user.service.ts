import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";

import { User } from "./user.model";
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class UserService {
  selectedUser: User = {
    FirstName: '',
    MiddleName: '',
    LastName: '',
    Age: 0,
    Gender: '',
    Mobile: '',
    PhoneNo: '',
    EmailId: '',
    AddressLine1: '',
    AddressLine2: '',
    AddressLine3: '',
    PhotoPath: '',
    Password: '',
    CreatedBy: 0,
    CreatedAt: null,
    UpdatedBy: 0,
    UpdatedAt: null
  }

  constructor(private http: HttpClient) {
    this.selectedUser=<User>{};
  }

  postUser(user: User) {
    return this.http.post(environment.apiBaseUrl + '/register', user)
  }
}
