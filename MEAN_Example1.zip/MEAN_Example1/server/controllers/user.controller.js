const mongoose = require('mongoose');

const User = mongoose.model('User');


module.exports.register = (req, res, next) => {
    var user = new User();
    user.FirstName = req.body.FirstName;
    user.MiddleName = req.body.MiddleName;
    user.LastName = req.body.LastName;
    user.Age = req.body.Age;
    user.Gender = req.body.Gender;
    user.Mobile = req.body.Mobile;
    user.PhoneNo = req.body.PhoneNo;
    user.EmailId = req.body.EmailId;
    user.AddressLine1 = req.body.AddressLine1;
    user.AddressLine2 = req.body.AddressLine2;
    user.AddressLine3 = req.body.AddressLine3;
    user.PhotoPath = req.body.PhotoPath;
    user.Password = req.body.Password;
    user.SaltSecret = req.body.SaltSecret;
    user.CreatedBy = req.body.CreatedBy;
    user.CreatedAt = req.body.CreatedAt;
    user.UpdatedBy = req.body.UpdatedBy;
    user.UpdatedAt = req.body.UpdatedAt;

    user.save((err, doc) => {
        if (!err) {
            res.send(doc);
        } else {
            if (err.code === 11000) {
                res.status(422).send(['Duplicate User Found...']);
            } else {
                return next(err);
            }
        }
    })
}