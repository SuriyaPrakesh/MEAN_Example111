const mongoose = require('mongoose');

mongoose.connect(process.env.MONGODB_URI, (err) => {
    if (!err) {
        console.log('Mongo DB Connection Succeeded...');
    } else {
        console.log('Error while connecting DB = ' + JSON.stringify(err, undefined, 2));
    }
});

require('./user.model');