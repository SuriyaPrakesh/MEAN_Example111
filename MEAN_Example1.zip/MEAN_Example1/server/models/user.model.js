const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

var UserSchema = new mongoose.Schema({
    FirstName: {
        type: String,
        required: 'Full Name Can Not Be Empty...'
    },
    MiddleName: {
        type: String
    },
    LastName: {
        type: String,
        required: 'Last Name Can Not Be Empty...'
    },
    Age: {
        type: Number,
        required: 'Age Can Not Be Empty...'
    },
    Gender: {
        type: String,
        required: 'Gender Can Not Be Empty...'
    },
    Mobile: {
        type: String,
        required: 'Mobile Can Not Be Empty...',
        unique: true
    },
    PhoneNo: {
        type: String
    },
    EmailId: {
        type: String,
        required: 'EmailId Can Not Be Empty...',
        unique: true
    },
    AddressLine1: {
        type: String
    },
    AddressLine2: {
        type: String
    },
    AddressLine3: {
        type: String
    },
    PhotoPath: {
        type: String
    },
    Password: {
        type: String,
        required: 'Password Can Not Be Empty...',
        minlength: [4, 'Password must be atleast 4 character long...']
    },
    SaltSecret: {
        type: String
    },
    CreatedBy:{
        type: Number
    },
    CreatedAt: {
        type: Date
    },
    UpdatedBy: {
        type: Number
    },
    UpdatedAt: {
        type: Date
    }
});

UserSchema.path('EmailId').validate((val) => {
    EmailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return EmailRegex.test(val);
}, 'Invalid Email Id...');

UserSchema.pre('save', function(next){
    bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(this.Password, salt, (err, hash) => {
            this.Password = hash;
            this.SaltSecret = salt;
            next();
        });
    });
});

mongoose.model('User', UserSchema);